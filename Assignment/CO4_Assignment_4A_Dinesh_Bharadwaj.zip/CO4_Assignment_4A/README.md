# CO4 Assignment 4A – Dinesh Bharadwaj

Registration Number: 192572028

## Contents
- `Source_Code/Task_1` through `Task_6`: task-wise language-independent pseudocode, explanations and traces.
- `Report/CO4_Assignment_4A_Report.pdf`: consolidated report covering all six tasks.
- This `README.md`.

## Important compliance note
The supplied assignment PDF explicitly states on page 1 that this is not a programming assignment and that a compiler/programming language is not required. Pages 8–9 further state that C/C++/Java/Python code will not be accepted as pseudocode and that the Day-4 Design Challenge (Task 6) is compulsory. Therefore, this submission provides algorithmic pseudocode, manual desk-checks, calculations, test cases and reasoning rather than executable programs or fabricated execution screenshots. Please follow any newer written instruction issued by your faculty if it supersedes the attached assignment brief.

## Submission
Upload the complete `CO4_Assignment_4A` folder to your GitHub repository, preserving the directory structure.
