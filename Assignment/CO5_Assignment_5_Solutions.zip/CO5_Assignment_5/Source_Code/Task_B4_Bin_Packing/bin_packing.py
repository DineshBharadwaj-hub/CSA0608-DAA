"""
First-Fit Decreasing (FFD) heuristic for identical-capacity bin packing.
"""
from typing import List

def first_fit_decreasing(items: List[float], capacity: float):
    if capacity <= 0 or any(x < 0 or x > capacity for x in items):
        raise ValueError("Capacity must be positive and each item in [0, capacity].")
    ordered=sorted(enumerate(items),key=lambda p:(-p[1],p[0]))
    bins=[]; assignments=[]
    for original,size in ordered:
        placed=False
        for idx,remaining in enumerate(bins):
            if size <= remaining + 1e-12:
                bins[idx]-=size; assignments.append((original,idx)); placed=True; break
        if not placed:
            bins.append(capacity-size); assignments.append((original,len(bins)-1))
    allocation=[[] for _ in bins]
    for original,idx in assignments: allocation[idx].append((original,items[original]))
    return allocation,bins

def demo():
    capacity=10
    workloads=[6,6,6,4,4,4,3,3,2]
    allocation,remaining=first_fit_decreasing(workloads,capacity)
    print("Capacity:",capacity)
    print("Servers used:",len(allocation))
    for i,(items,left) in enumerate(zip(allocation,remaining),1):
        print(f"Server {i}: {items}; remaining capacity={left}")
    # Example where simple input-order First Fit can be worse than FFD:
    # compare for reproducible illustrative sequence.
    print("Heuristic: First-Fit Decreasing; sort descending, then first feasible server.")
if __name__=="__main__": demo()
