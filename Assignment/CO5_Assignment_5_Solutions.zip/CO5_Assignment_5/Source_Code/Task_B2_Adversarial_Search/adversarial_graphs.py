from graph_colouring import colour_graph

# Both graphs have 7 vertices and use k=3.
# Easy: a tree, which is 2-colourable.
easy = {i: [] for i in range(7)}
for i in range(1,7):
    easy[i].append((i-1)//2); easy[(i-1)//2].append(i)

# Difficult/infeasible under k=3: complete graph K4 plus isolated vertices.
# Input order places isolated vertices first, delaying the K4 contradiction.
hard = {i: [] for i in range(7)}
for i in range(4):
    hard[i] = [j for j in range(4) if j != i]
for i in range(4,7):
    hard[i] = []

for name,g in [("Graph A: tree",easy),("Graph B: K4 + isolated",hard)]:
    solution, stats=colour_graph(g,3,heuristic=False)
    print(name, "solution=",solution, "stats=",stats)
