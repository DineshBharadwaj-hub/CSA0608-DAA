"""
Exact minimum Set Cover and greedy max-new-coverage approximation.
Input: universe set and list of centre coverage sets.
"""
from itertools import combinations

def exact_cover(universe, centres):
    # Try cardinalities in increasing order; combinations_count is instrumentation.
    tested=0
    for size in range(len(centres)+1):
        for chosen in combinations(range(len(centres)),size):
            tested += 1
            covered=set()
            for i in chosen: covered |= set(centres[i])
            if set(universe) <= covered:
                return list(chosen), tested
    return None, tested

def greedy_cover(universe, centres):
    uncovered=set(universe); selected=[]; steps=0
    while uncovered:
        steps += 1
        gains=[len(set(c)&uncovered) for c in centres]
        best=max(range(len(centres)),key=lambda i:(gains[i],-i))
        if gains[best]==0:
            return None,steps
        selected.append(best)
        uncovered -= set(centres[best])
    return selected,steps

def run_demo():
    cases=[
        ("Case 1",set("abcd"),[set("ab"),set("cd"),set("ac")]),
        ("Case 2",set("abcde"),[set("abc"),set("de"),set("ab"),set("cd")]),
        ("Case 3",set("abcdef"),[set("ab"),set("cd"),set("ef"),set("ace"),set("bdf")]),
        # Greedy counterexample: greedy takes A (covers 4); optimum B+C (3+3)
        ("Counterexample",set(range(6)),[set(range(4)),{0,1,4},{2,3,5}]),
    ]
    print("B3 exact vs greedy")
    for name,u,c in cases:
        e,ec=exact_cover(u,c); g,gc=greedy_cover(u,c)
        print(name, "exact=",e,"size",len(e) if e else None,"combinations",ec,
              "greedy=",g,"size",len(g) if g else None,"steps",gc)
    print("Scalability (all centres cover one unique zone; exact enumerates all subsets)")
    for n in [8,12,16,20]:
        u=set(range(n)); c=[{i} for i in range(n)]
        e,ec=exact_cover(u,c); g,gc=greedy_cover(u,c)
        print(n, "exact combinations",ec,"greedy selections",gc)

if __name__=="__main__": run_demo()
