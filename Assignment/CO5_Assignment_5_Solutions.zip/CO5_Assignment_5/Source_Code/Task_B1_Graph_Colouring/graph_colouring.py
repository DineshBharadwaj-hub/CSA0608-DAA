"""
CO5 B1/B2: Instrumented graph colouring with input-order and DSATUR-style ordering.
Graph: adjacency list/dict, vertices are arbitrary hashable labels.
Counters are per run.
"""
from dataclasses import dataclass
from typing import Dict, List, Optional, Hashable

@dataclass
class Stats:
    nodes: int = 0
    attempts: int = 0
    rejected: int = 0
    backtracks: int = 0
    max_depth: int = 0

def colour_graph(graph: Dict[Hashable, List[Hashable]], k: int,
                heuristic: bool = False):
    vertices = list(graph)
    colour = {}
    stats = Stats()

    def choose_vertex():
        unassigned = [v for v in vertices if v not in colour]
        if not heuristic:
            return unassigned[0] if unassigned else None
        # DSATUR-inspired: maximum distinct neighbour colours,
        # then maximum degree, then stable input order.
        return max(unassigned, key=lambda v: (
            len({colour[n] for n in graph[v] if n in colour}),
            len(graph[v]), -vertices.index(v)))

    def search(depth):
        stats.nodes += 1
        stats.max_depth = max(stats.max_depth, depth)
        if len(colour) == len(vertices):
            return True
        v = choose_vertex()
        for c in range(1, k + 1):
            stats.attempts += 1
            if any(colour.get(n) == c for n in graph[v]):
                stats.rejected += 1
                continue
            colour[v] = c
            if search(depth + 1):
                return True
            del colour[v]             # undo assignment
            stats.backtracks += 1
        return False

    possible = search(0)
    return (dict(colour) if possible else None), stats

def complete_graph(n):
    return {i: [j for j in range(n) if j != i] for i in range(n)}

def cycle_graph(n):
    return {i: sorted({(i-1)%n, (i+1)%n} - {i}) for i in range(n)}

def demo():
    tests = [
        ("triangle, k=3", complete_graph(3), 3),
        ("triangle, k=2 (impossible)", complete_graph(3), 2),
        ("empty graph, k=1 (boundary)", {0:[],1:[],2:[]}, 1),
    ]
    print("B1 VALIDATION")
    for name,g,k in tests:
        ans,s=colour_graph(g,k)
        print(f"{name}: solution={ans}; nodes={s.nodes}, attempts={s.attempts}, rejected={s.rejected}, backtracks={s.backtracks}, depth={s.max_depth}")
    print("\nB1 ORDER COMPARISON (same graph, k=3)")
    g={0:[1,2,3],1:[0,2],2:[0,1,3],3:[0,2,4],4:[3,5],5:[4]}
    for h in [False,True]:
        ans,s=colour_graph(g,3,h)
        print(("heuristic" if h else "input-order"),ans,s)

if __name__=="__main__":
    demo()
