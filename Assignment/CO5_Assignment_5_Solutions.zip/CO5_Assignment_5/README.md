# CO5 Assignment 5 — Search, Complexity and Approximation Engineering

This repository contains answers to all five Part A design tasks and four Part B implementation tasks (nine tasks total), based on the supplied CO5 assignment PDF.

## Structure
- `Source_Code/Task_B1_Graph_Colouring/graph_colouring.py` — instrumented backtracking, tests, ordering comparison
- `Source_Code/Task_B2_Adversarial_Search/adversarial_graphs.py` — same-size graph experiment
- `Source_Code/Task_B3_Exact_vs_Approximation/set_cover.py` — exact and greedy set cover
- `Source_Code/Task_B4_Bin_Packing/bin_packing.py` — First-Fit Decreasing workload placement
- `Report/CO5_Assignment_5_Report.pdf` — consolidated Part A and Part B report

## Run
Use Python 3.9+ (standard library only):
```bash
python Source_Code/Task_B1_Graph_Colouring/graph_colouring.py
PYTHONPATH=Source_Code/Task_B1_Graph_Colouring python Source_Code/Task_B2_Adversarial_Search/adversarial_graphs.py
python Source_Code/Task_B3_Exact_vs_Approximation/set_cover.py
python Source_Code/Task_B4_Bin_Packing/bin_packing.py
```

## Assumptions
The assignment PDF omits some numerical inputs (e.g. target, graph colour count, zone coverage data and server capacity). This solution makes explicit illustrative choices in the report; replace them with instructor-provided values if available. The graph-colouring tests use k=3 (and k=2 for the infeasible triangle); the subset-sum trace uses positive set `{3, 4, 5, 8}` and target `9`; bin packing uses capacity 10.

## Validation
All code is instrumented and the report includes captured execution results, test purpose, limitations, complexity, and interpretation. Run the scripts locally to regenerate the terminal outputs.
